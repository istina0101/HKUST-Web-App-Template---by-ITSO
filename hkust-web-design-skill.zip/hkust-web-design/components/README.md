# Component reference · HKUST Web

One entry per component: what & when, a usage example, notes. Source is the sibling `.jsx` in `components/<group>/`; props are documented in each file's JSDoc.

## core

### Avatar

Initials avatar for people; the portal has no photos.

```jsx
<Avatar initials="FM" />
<Avatar initials="J" size="lg" />
<Avatar initials="FA" bg="var(--tint-gold-bg)" fg="var(--hkust-gold)" />
```

- Persona colour pairs: navy (#e6ecf3 / --hkust-blue), gold (#f3ecdd / --hkust-gold), cyan (#e2f4fa / #1d7fb0), green (#e1f3ec / #067a4e).

### Badge

Badge for statuses, layers and flags; the tint set is shared with Callout.

```jsx
<Badge tone="success" icon="check">Active</Badge>
<Badge tone="warning" icon="clock">Sensitive · time-bound</Badge>
<Badge tone="gold" icon="stamp">By approval</Badge>
<Badge tone="neutral">L1 · Basic</Badge>
```

- Tone meanings in the portal: info = automatic/system, success = active/approved, warning = pending/sensitive, danger = rejected/high risk, gold = approval/L3, neutral = completed/disabled.
- Badges never wrap. For a long value in a KeyValueList (e.g. an approval route), pass `style={{ whiteSpace: 'normal', textAlign: 'left', alignItems: 'flex-start' }}` so it breaks onto a second line instead of overflowing on narrow screens.

### Button

Button for every clickable action; primary is ITSO blue and darkens to HKUST navy on hover.

```jsx
<Button icon="circle-plus">Request an app</Button>
<Button variant="ghost" size="sm" icon="eye">View</Button>
<Button variant="link">Cancel</Button>
<Button variant="danger-solid" icon="trash-2">Remove access</Button>
```

- One primary per view section; ghost for secondary; link for cancel/dismiss inside modals and rows. Link buttons are borderless at rest and reveal their 40px/32px box with a pale-grey (`--bg2`) fill on hover.
- `danger` is the outlined red used in rows; `danger-solid` confirms destructive modals.
- Two sizes only: md is 40px tall (0 16px, 14px text) for page and card actions; `size="sm"` is 32px (0 11px, 12px text) for table and card-row actions. Never mix the two in one row; both match Input/Select heights.

### Card

The one container: everything on a page sits in a Card on the pale page background.

```jsx
<Card>
  <SectionTitle>Password</SectionTitle>
  <p className="muted">Last changed 12 Mar 2026 · meets policy</p>
</Card>
<Card flush>
  <CardHeader title="Multi-factor authentication" subtitle="Used to confirm it is really you" actions={<Badge tone="success" icon="shield-check">Active</Badge>} />
  …rows…
  <CardFooter><Button size="sm" icon="plus">Add a method</Button></CardFooter>
</Card>
```

- Cards never nest. Grids of cards use 16px gaps.
- `hoverable` only when the whole card is a link.

### Chip

Chips are the portal's filter and segment pattern ("All · HR systems · IT tools", "Myself · On behalf of someone").

```jsx
<ChipGroup>
  <Chip selected>All (14)</Chip>
  <Chip>Your reports</Chip>
  <Chip>Not yet reviewed</Chip>
</ChipGroup>
```

- Exactly one selected chip per group.
- Use Tabs (addition) only for switching whole content panes.

### Icon

Inline Lucide icon; use it wherever the portal shows an 18px stroke glyph (nav rows, buttons, badges, callouts).

```jsx
<Icon name="shield-check" />
<Icon name="clock" size={13} style={{ color: 'var(--warning)' }} />
```

- Only ids in `ICONS` render (the portal's ~70 glyphs plus a few additions: chevrons, settings, download, filter, trending-up/down, external-link, log-out, inbox, more-horizontal).
- Never use emoji or hand-drawn SVG in place of an icon.

### IconBox

Icon tile that leads app cards, stat tiles, MFA rows and system cells.

```jsx
<IconBox icon="layout-grid" />
<IconBox icon="users" tone="green" />
<IconBox icon="building-2" tone="navy" size={30} />
```

- Tone is categorical, not status: navy = apps/departments, cyan = data systems, green = people/HR, gold = finance/approvals, red = destructive modals, gray = not set up.

### IconButton

Square icon-only button for toolbars and the top band.

```jsx
<IconButton icon="bell" dot title="Notifications" />
<IconButton icon="shopping-cart" count={2} title="Access cart" />
<IconButton icon="more-horizontal" tone="light" title="More" />
```

- Always pass `title` (it doubles as aria-label).
- `tone="navy"` icons are pale blue-grey (#cdd8e6) and turn white on hover.

### Tag

Small inline label for a category on a card.

```jsx
<Tag>SSO</Tag>
```

- One tag per card; use Badge when the label carries status.

## data

### Accordion

Settings sections, FAQ-style help, grouped details.

```jsx
<Accordion items={[{ key: 'profile', title: 'Profile', meta: 'Synced from HR', content: <…/> }, { key: 'notify', title: 'Notifications', content: <…/> }]} />
```

- Opens one section at a time; chevron rotates 180° in 150ms. Header 16px 22px, body 0 22px 18px.

### ActivityList

Audit log / activity panel.

```jsx
<ActivityList items={[{time:'01 Aug 2026 09:01',text:'Identity created · harvey@ust.hk',meta:'IAM platform · JNR-2214'}]} />
```

- Timestamps are "DD Mon YYYY HH:MM".

### BarChart

Counts by category or month.

```jsx
<BarChart data={[{label:'Jan',value:42},{label:'Feb',value:57}]} showValues />
```

- Square bars, ITSO blue first series, HKUST grid grey; second series is light blue.
- Hover: the hovered bar stays solid while others dim to 35%, its label turns navy bold, and a white tooltip card shows label + value(s) — the same interaction as the Chart.js theme. `seriesNames` labels grouped bars in the tooltip.

### KeyValueList

Record facts on a detail page.

```jsx
<KeyValueList items={[{k:'Staff ID',v:'UST-P-0045210'},{k:'Status',v:<Badge tone="success" icon="check">Active</Badge>}]} />
```

- Keys are 14px semibold grey; values 14px body.

### KpiDelta

Delta under a StatTile number.

```jsx
<KpiDelta value="+12%" direction="up" label="vs last month" />
<KpiDelta value="-8%" direction="down" invert label="open tickets" />
```

- Green/red follow outcome, not direction.

### LineChart

Trends over time.

```jsx
<LineChart labels={['Mar','Apr','May','Jun']} series={[{name:'Requests',values:[120,140,131,168]},{name:'Approvals',values:[98,121,119,150]}]} />
```

- 2px lines, white-filled dots, faint area under the first series.
- Hover: a dashed guide line, enlarged dots and a white tooltip card listing every series' value at that x — same interaction as the Chart.js theme.

### StatTile

Home tiles and dashboard KPIs; 3 per row.

```jsx
<StatTile eyebrow="Approvals waiting on you" value={2} caption="Review each item individually" icon="stamp" tone="gold" action={<Button variant="link" style={{paddingLeft:0}}>Review approvals →</Button>} />
```

- Pass `children` for a KpiDelta or Badge under the number.
- Give tiles at least 220px (`repeat(auto-fit,minmax(220px,1fr))`); below 200px the tile drops its IconBox automatically so the text keeps room.

### StepTracker

Where a request is in its route.

```jsx
<StepTracker steps={[{label:'Submitted',state:'done'},{label:'Policy & SoD',state:'done'},{label:'Manager (FO)',state:'active'},{label:'Provisioning',state:'pending'},{label:'Ready',state:'pending'}]} />
```

- done = green check, active = blue clock, error = red x, pending = grey pip. Use `vertical` under 760px.

### Table

Lists of people, grants, requests. Put it in a flush Card.

```jsx
<Card flush>
  <Table emphasis="system" columns={[{key:'system',label:'System'},{key:'role',label:'Business role'},{key:'status',label:'Status',render:r=><Badge tone={r.tone}>{r.status}</Badge>},{key:'act',label:'',align:'right',render:r=><Button variant="link" size="sm" icon="eye">View</Button>}]} rows={rows} />
</Card>
```

- Header is 11px uppercase grey on pale grey; cells 14px with 13px 14px padding.
- Right-align the action column; leave its header empty.

- At ≤760px each row stacks into a block — bold first cell, then label · value lines — separated by hairlines inside the same card (the portal's "cardify", flattened so borders never double up); pass `breakpoint={0}` to keep the grid.
- Sorting (addition): flag columns `sortable`, hold `sort` in state and flip dir in `onSort`; `SortRows(rows, sort)` orders them. Selection (addition): `selectable` + `selected`/`onSelectionChange`, with `<BulkBar count={selected.length} onClear>` above the table holding the bulk actions.

## feedback

### Callout

Explain a rule or consequence next to the control it affects.

```jsx
<Callout>Self-service reset replaces the helpdesk ticket. Most resets finish in under a minute once MFA is confirmed.</Callout>
<Callout tone="warning" icon="info">This takes effect immediately and is written to the audit log.</Callout>
```

- One callout per card at most. Text is 14px in the tone's dark foreground.

### Drawer

Detail view that keeps the list underneath (member details, request preview).

```jsx
<Drawer open={!!member} onClose={() => setMember(null)} title={member.n} subtitle={member.role} leading={<Avatar initials="LJ" size="lg" />} footer={<><Button variant="link">Close</Button><Button icon="user-x" variant="danger">Remove from project</Button></>}>
  <KeyValueList items={…} />
</Drawer>
```

- Header, body and footer insets match Modal; only the × closes it (no scrim click, no Esc) so accidental taps don't lose the panel.

### EmptyState

What a list shows when a filter or view has nothing.

```jsx
<Card><EmptyState icon="users-round" title="No events in this view">Switch filter to see other team events.</EmptyState></Card>
```

- Icon 30px grey; keep copy to one sentence.

### Modal

Dialogs for confirmations, short forms and wizards.

```jsx
<Modal title="Reject request" subtitle="TRF-1027 · ECM" leading={<IconBox icon="x" tone="red" size={34} />} onClose={close}
  footer={<><Button variant="link" onClick={close}>Cancel</Button><Button variant="danger-solid">Confirm rejection</Button></>}>
  …OptionRows / Field…
</Modal>
```

- Footer is space-between: link-style Cancel left, primary right. Wizards put Back left.
- Destructive dialogs lead with a 34px red IconBox and confirm with `danger-solid`.

### NotificationBanner

Page-wide notice that pushes content down; place directly under the band, above PageHead.

```jsx
<NotificationBanner tone="warning" title="Planned maintenance" action={<Button variant="link" size="sm">Details →</Button>}>
  ITSO systems will be unavailable on Sun 14 Sep, 02:00–06:00.
</NotificationBanner>
```

- One banner at a time; always dismissible (× on the right).
- Tones follow the shared tint set: info maintenance · warning expiring · danger outage · success completed.

### NotificationPanel

Bell dropdown: 340px white card with unread dots, "Mark all as read" and a View action per item.

```jsx
<NotificationPanel open={open} onClose={close} onMarkAllRead={markAll} items={[{ id: 1, title: 'Request REQ-5120 approved', meta: '2 hours ago · Research Computing', unread: true, icon: 'check', tone: 'green', onView }]} />
```

- Anchor inside a position:relative parent; default offset top 52 / right 60 (under the bell).

### Progress

Campaign completion and wizard position.

```jsx
<Progress value={43} />
<Progress variant="segments" steps={3} value={1} />
```

- Bar is 170px wide by default (certification header).

### Skeleton

Loading placeholders that mirror the layout they replace.

```jsx
<SkeletonCard />
<Card flush><SkeletonTable rows={5} cols={4} /></Card>
<Skeleton width={120} height={12} />
```

- 1.6s shimmer, plain ease, disabled under prefers-reduced-motion. Use Spinner for indeterminate waits without a known layout.

### Spinner

Indeterminate loading for a page or section.

```jsx
<Card flush><Spinner center label="Loading requests…" /></Card>
```

- Centre it in the section it blocks; not for buttons or inline text (decision Sep 2026).

### Toast

Confirm a completed action for ~3.6s.

```jsx
<Toast open={show}>Request submitted · TRF-1032</Toast>
```

- Navy fill, white 14px semibold text, no icon, no close button.

### Tooltip

Name an icon-only control.

```jsx
<Tooltip label="Download CSV"><IconButton tone="light" icon="download" title="Download CSV" /></Tooltip>
```

- Not in the IAM portal; added for icon-only actions.

## forms

### Checkbox

Row selection in tables and consent lines.

```jsx
<Checkbox checked={sel} onChange={setSel} />
<Checkbox label="Notify the requester" />
```

- Disabled+checked marks items already owned.

### Combobox

"Search name or staff ID…" fields that resolve to one person or record.

```jsx
<Combobox value={pi} onChange={setPi} placeholder="Search name or staff ID…" options={[{ value: 'wchan', label: 'Prof. CHAN Wing Hong', meta: 'UST-P-0031277 · Civil Engineering', initials: 'WH' }]} />
```

- Rows: 28px Avatar (or 16px icon), 14px label, 12px muted meta. Arrow keys move, Enter picks, Esc closes; the chosen row shows inside the field with a clear ×.

### Field

Form row wrapper.

```jsx
<Field label="Colleague you are requesting for" required hint="Approvals follow each system's own route.">
  <Input icon="user" placeholder="Search name or staff ID…" />
</Field>
```

- Required mark is a red asterisk after the label.

### FileUpload

Attachments on a request (justification letters, quotations).

```jsx
<FileUpload files={files} onFiles={add} onRemove={remove} hint="PDF or DOCX · up to 10 MB each" />
```

- Zone: dashed strong border on bg2, navy tint while dragging. Rows: 18px file icon, name · size, 160px progress bar while uploading, red tinted row with a reason when rejected.

### Input

Single-line text input; the search variant takes a leading icon.

```jsx
<Input icon="search" placeholder="Search systems, business roles, or functions…" />
<Field label="New password"><Input type="password" /></Field>
```

- Wrap in Field for label/hint. Full width by default; constrain with `wrapStyle={{maxWidth:340}}`.
- All controls share `--control-h` (40px; `Select size="sm"` 32px), so text, password, date and select fields line up in a row. Native date/number chrome is reset with `appearance:none`.

### MultiSelect

Choose several roles, members or departments.

```jsx
<MultiSelect value={ids} onChange={setIds} placeholder="Add members…" options={people.map(p => ({ value: p.id, label: p.n, meta: p.role }))} />
```

- Field reads "3 selected" with a small count pill; the list has a filter box and Select all / Clear.

### OptionRow

Choice list inside modals (MFA method, rejection reason).

```jsx
<OptionRow name="mfa" checked title="Security key / passkey" description="Phishing-resistant, fastest" trailing={<Badge tone="success">Recommended</Badge>} />
<OptionRow name="mfa" title="Authenticator app" description="One-time codes on your phone" />
```

- 9px gap between rows is built in.

### Radio

Bare radio; prefer OptionRow for described choices.

```jsx
<Radio name="dur" value="90" checked label="90 days" />
```

- Group by `name`.

### SegmentedControl

Keep / Revoke decisions in certification tables.

```jsx
<SegmentedControl size="sm" value={d} onChange={setD} options={[{value:'keep',label:'Keep',tone:'success'},{value:'revoke',label:'Revoke',tone:'danger'}]} />
```

- Use `size="sm"` inside table cells.

### Select

Dropdown for short fixed lists (durations, departments).

```jsx
<Select options={['30 days','90 days','180 days']} defaultValue="90 days" size="sm" />
```

- Prefer Chips for ≤5 visible choices; Select for longer lists.

### Switch

On/off setting.

```jsx
<Switch checked={on} onChange={setOn} label="Email me when a request is decided" />
```

- Checked track is ITSO blue; unchecked is the strong border grey.

### Textarea

Justification / comment box.

```jsx
<Field label="Business justification" required>
  <Textarea rows={3} placeholder="Explain why you need these roles." />
</Field>
```

- 2–3 rows in modals and cards.

## navigation

### Breadcrumb

Path back up from a detail page.

```jsx
<Breadcrumb items={[{label:'Team members',onClick:back},{label:'WONG Ka Ming'}]} />
```

- Place above PageHead's title or as the first line of the content area.

### DropdownMenu

User / persona menu and row overflow menus.

```jsx
<DropdownMenu open={open} heading="Switch user · prototype">
  <MenuItem leading={<Avatar initials="FM" />} label="FO Manager" description="Manager · Finance Office" selected />
  <MenuItem icon="log-out" label="Sign out" tone="danger" />
</DropdownMenu>
```

- Anchor inside a `position:relative` parent; default offset is top 52 / right 12 (under the band user chip).

### PageHead

Every page starts with one.

```jsx
<PageHead title="Request Access" subtitle="Browse the catalogue and request the access you need" />
```

- Title Case for page titles (they mirror nav labels); sentence case for the subtitle.

### Pagination

Below long tables.

```jsx
<Pagination page={p} pages={8} onChange={setP} summary="1–20 of 143" />
```

- 32px squares; active is pale-navy fill.

### Sidebar

Left navigation under the band.

```jsx
<Sidebar collapsible title="IAM Self-Service Portal" footer="prototype v4 · staff identity">
  <NavItem icon="layout-grid" active>Home & Apps</NavItem>
  <NavLabel>My access</NavLabel>
  <NavItem icon="clipboard-list" count={2}>My Requests</NavItem>
</Sidebar>
```

- Groups are uppercase 11px labels; the first item (Home) has no label.
- Active row: pale-navy fill, navy text, 3px ITSO-blue bar on the left.

- Responsive: at ≤880px the sidebar is an off-canvas drawer opened by the band's menu button and closed by tapping the navy backdrop or any NavItem.
- `title` puts the system name in a header row; `collapsible` adds the panel toggle at its right, which shrinks the rail to 64px icons on desktop (labels become tooltips). On phones the band's ☰ opens the drawer instead. Page content should use `marginLeft: 'var(--side-w-current, var(--side-w))'` to follow.
- Long system names wrap to at most 2 lines (ellipsis after, full name on hover). Names that would need a third line should use the acronym staff already use (e.g. "CADS") and put the full name in the page subtitle.

### Tabs

Switch between panes of one record (Overview · Access · Activity).

```jsx
<Tabs value={tab} onChange={setTab} items={[{key:'o',label:'Overview'},{key:'a',label:'Access',count:9},{key:'h',label:'Activity'}]} />
```

- Filters stay Chips; Tabs are for panes.

### TopBand

The brand signature on every app screen.

```jsx
<TopBand logoSrc="assets/logo/hkust-fullname-white.png" unit="Information Technology" unitSub="Services Office (ITSO)" user={{initials:'FM',name:'FO Manager',role:'Manager · Finance Office'}} onUserClick={openMenu}>
  <IconButton icon="search" title="Search" />
  <IconButton icon="bell" dot title="Notifications" />
</TopBand>
```

- Logo always left, 34px tall, white version on navy.
- Unit block is 12px white with a 1px 40%-white left rule.

- Responsive: ≤880px hides the unit block and user text and shows ☰ before the logo (opens the Sidebar drawer). On desktop the logo is always first; the sidebar collapse toggle lives in the Sidebar header.
